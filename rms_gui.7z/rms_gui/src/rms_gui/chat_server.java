package rms_gui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Color;
/**
 *
 * @author Shady
 */
public class chat_server extends javax.swing.JFrame {
    
   private static final long serialVersionUID = 1L;
   private Server server;
    /*public chat_server() {
        initComponents();
        appendRoom("Chatlog.\n");
        appendEvent("Events.\n");
    }*/
    
    public chat_server(int port)
    {
        initComponents();
        appendRoom("Chatlog.\n");
        appendEvent("Events.\n");
        setVisible(true);
        server = null;
    }
    
    void appendRoom(String str) {
        chat.append(str);
        chat.setCaretPosition(chat.getText().length() - 1);
    }

    void appendEvent(String str) {
        event.append(str);
        event.setCaretPosition(chat.getText().length() - 1);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kGradientPanel1 = new com.k33ptoo.components.KGradientPanel();
        stafflogin = new javax.swing.JLabel();
        portnumb = new javax.swing.JLabel();
        stopStart = new com.k33ptoo.components.KButton();
        win_exit = new javax.swing.JLabel();
        port_field = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        chat = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        jScrollPane3 = new javax.swing.JScrollPane();
        event = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        kGradientPanel1.setBackground(new Color(0,0,0,0));
        kGradientPanel1.setkEndColor(new java.awt.Color(52, 152, 219));
        kGradientPanel1.setkGradientFocus(50);
        kGradientPanel1.setkStartColor(new java.awt.Color(46, 204, 113));
        kGradientPanel1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                kGradientPanel1MouseDragged(evt);
            }
        });
        kGradientPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                kGradientPanel1MousePressed(evt);
            }
        });
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        stafflogin.setFont(new java.awt.Font("Segoe UI Semibold", 0, 36)); // NOI18N
        stafflogin.setForeground(new java.awt.Color(255, 255, 255));
        stafflogin.setText("CHAT SERVER");
        kGradientPanel1.add(stafflogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 30, -1, -1));

        portnumb.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        portnumb.setForeground(new java.awt.Color(255, 255, 255));
        portnumb.setText("Port Number:");
        kGradientPanel1.add(portnumb, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 90, -1));

        stopStart.setText("Start");
        stopStart.setkBackGroundColor(new java.awt.Color(255, 255, 255));
        stopStart.setkBorderRadius(40);
        stopStart.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        stopStart.setkHoverStartColor(new java.awt.Color(0, 204, 204));
        stopStart.setkPressedColor(new java.awt.Color(52, 152, 219));
        stopStart.setkSelectedColor(new java.awt.Color(255, 255, 255));
        stopStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stopStartActionPerformed(evt);
            }
        });
        kGradientPanel1.add(stopStart, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 120, 180, -1));

        win_exit.setBackground(new java.awt.Color(0, 153, 204));
        win_exit.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        win_exit.setForeground(new java.awt.Color(255, 255, 255));
        win_exit.setText("X");
        win_exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                win_exitMouseClicked(evt);
            }
        });
        kGradientPanel1.add(win_exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 10, 20, 30));

        port_field.setBackground(new Color(0,0,0,0));
        port_field.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        port_field.setForeground(new java.awt.Color(255, 255, 255));
        port_field.setText("1500");
        port_field.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        port_field.setCaretColor(new java.awt.Color(52, 152, 219));
        port_field.setOpaque(false);
        port_field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                port_fieldActionPerformed(evt);
            }
        });
        kGradientPanel1.add(port_field, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 100, 40));

        chat.setEditable(false);
        chat.setColumns(20);
        chat.setRows(5);
        jScrollPane1.setViewportView(chat);

        jScrollPane2.setViewportView(jScrollPane1);

        kGradientPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 640, 300));

        event.setEditable(false);
        event.setColumns(20);
        event.setRows(5);
        jScrollPane3.setViewportView(event);

        jScrollPane4.setViewportView(jScrollPane3);

        kGradientPanel1.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 480, 640, 230));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(kGradientPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 661, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kGradientPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 727, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void stopStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stopStartActionPerformed
        if (server != null) {
            server.stop();
            server = null;
            port_field.setEditable(true);
            stopStart.setText("Start");
            return;
        }
        int port;
        try {
            port = Integer.parseInt(port_field.getText().trim());
        } catch (Exception er) {
            appendEvent("Invalid port number");
            return;
        }
        server = new Server(port, this);
        new ServerRunning().start();
        stopStart.setText("Stop");
        port_field.setEditable(false);
    }//GEN-LAST:event_stopStartActionPerformed

    private void kGradientPanel1MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kGradientPanel1MouseDragged
        // TODO add your handling code here:
    }//GEN-LAST:event_kGradientPanel1MouseDragged

    private void kGradientPanel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kGradientPanel1MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_kGradientPanel1MousePressed

    private void win_exitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_win_exitMouseClicked
        if (server != null) {
            try {
                server.stop();
            } catch (Exception eClose) {
            }
            server = null;
        }
        dispose();
        System.exit(0);
    }//GEN-LAST:event_win_exitMouseClicked

    private void port_fieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_port_fieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_port_fieldActionPerformed

    /**
     * @param args the command line arguments
     */

    class ServerRunning extends Thread {

        public void run() {
            server.start();
            stopStart.setText("Start");
            port_field.setEditable(true);
            appendEvent("Server crashed\n");
            server = null;
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea chat;
    private javax.swing.JTextArea event;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private com.k33ptoo.components.KGradientPanel kGradientPanel1;
    private javax.swing.JTextField port_field;
    private javax.swing.JLabel portnumb;
    private javax.swing.JLabel stafflogin;
    private com.k33ptoo.components.KButton stopStart;
    private javax.swing.JLabel win_exit;
    // End of variables declaration//GEN-END:variables
}
